﻿//
// ARDUINOMODULES.INFO
// KY-022 Infrared Receiver Module
//
// https://arduinomodules.info/ky-022-infrared-receiver-module/
//



File includes:
 |
 |- KY-022 Infrared Receiver Module.fzpz		//Fritzing Custom Part
 |
 |- Readme.txt						//This file 



Changelog:
  
  Oct-2020
    -Fix PCB holes.
    -Fix PCB size.
    -Fix copper layers order on PCB.


Disclaimer:

KY-022 Infrared Receiver Module
 Fritzing Part is created by arduinomodules.info and published under Creative Commons Attribution-ShareAlike 4.0 International license (https://creativecommons.org/licenses/by-sa/4.0/).
You can use it, share it and/or modify it for any purposes as long as you distribute it under the same license and provide appropriate credit.
